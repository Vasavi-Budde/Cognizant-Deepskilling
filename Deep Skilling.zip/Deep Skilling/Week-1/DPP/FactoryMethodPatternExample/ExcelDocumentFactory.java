package DPP.FactoryMethodPatternExample;

public class ExcelDocumentFactory extends DocumentFactory {

    @Override
    public Document createDocument() {

        return new ExcelDocument();
    }
}